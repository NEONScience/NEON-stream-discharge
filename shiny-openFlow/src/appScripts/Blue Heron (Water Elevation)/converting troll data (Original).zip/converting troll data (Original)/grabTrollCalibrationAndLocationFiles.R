
####fields for converting troll pressure to water table elevation

#Step 1: grab cal files
#put these 2 files in a local folder and update the path below to read them in
source('N:/Science/AQU/Nora/def.read.cal.xml.rest.R')
source('N:/Science/AQU/Nora/grabCalibrations.R')


###User set variables to ENTER
#set DPname to either 'SW_elev' or 'GW_elev'
DPname <- 'SW_elev'
site <- 'LECO'
domain <- 'D07'
#update to a date range that you know the troll in question was installed (small date range is better for not returning multiple cal files)
startDate<-as.POSIXct('2023-08-12', format="%Y-%m-%d")
endDate<-as.POSIXct('2023-08-13', format="%Y-%m-%d")
#Set the HOR for the location of interest (surface water locations are 101,102,131,132,110 and groundwater locations are 301-308 for wells 1-8)
HOR<-'301'

#run this to compile DP Ids
if(DPname=='GW_cond'){
  DPnum<-"DP0.20015.001.01371"
  VER<-"000"
}else if(DPname=='GW_elev'){
  DPnum<-"DP0.20015.001.01376"
  VER<-"000"
}else if(DPname=='GW_temp'){
  DPnum<-"DP0.20015.001.01374"
  VER<-"000"
}else if(DPname=='SW_elev_leveltroll'){
  DPnum<-"DP0.20016.001.01379"
  VER<-"100"
}else if(DPname=='SW_elev_aquatroll'){
  DPnum<-"DP0.20054.001.01376"
  VER<-"100"
}else if(DPname=='SW_cond'){
  DPnum<-"DP0.20054.001.01371"
  VER<-"100"
}else if(DPname=='SW_temp'){
  DPnum<-"DP0.20054.001.01374"
  VER<-"100"
}

#run to pull calibrations
calibrations<-grabCalibrations(CDSURL ="http://den-certcdsllb-1.ci.neoninternal.org/cdsWebApp/",
                               startDate = startDate,
                               endDate = endDate,
                               DPID = paste("NEON",domain,site,DPnum,HOR,VER,"000",sep="."))

getwd()
#writes out to your working directory
write.csv(calibrations,paste(site,'_',HOR,"_calfile_202201_",DPname,".csv",sep=''),row.names = F)



#STEP 2: Grab sensor elevation data
# install.packages("neonUtilities") 
# devtools::install_github("NEONScience/NEON-geolocation/geoNEON")  # work with NEON spatial data
library(neonUtilities)
library(geoNEON)
library(dplyr)

file<-paste(domain,site,"_currentLocations.csv", sep = "")

#get site history for all named locations
locations <- getLocBySite(site, type = "all", history = F)
locations_troll<-locations[grepl("Water Level",locations$locationDescription),]
locations_wells<-locations[grepl("Groundwater Well ",locations$locationDescription),]
locations<-rbind(locations_troll,locations_wells)
locations<-locations[!grepl("Not Used",locations$locationDescription),]

TrollLocations<-locations %>%
  select('namedLocation','locationDescription','domainID','siteID','elevation','zOffset')

write.csv(TrollLocations,paste(site,"_currentTrollLocations.csv",sep=''),row.names = F)





